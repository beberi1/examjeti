import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class SimpleCalculator implements Calculator {

    private static final Logger logger = Logger.getLogger(SimpleCalculator.class.getName());

    public SimpleCalculator() throws IOException {
        FileHandler fileHandler = new FileHandler("calculator.txt", true);
        SimpleFormatter formatter = new SimpleFormatter();
        fileHandler.setFormatter(formatter);
        logger.addHandler(fileHandler);
    }


    @Override
    public int add(int a, int b) throws ArithmeticException {
        try{
            int result = a + b;
            logger.info("Numbers added: " + a + " + " + b + " = " + result);
            return result;
        } catch (Exception e){
            logger.warning("rashobi dzma " + e);
        }
        return a;
    }

    @Override
    public int subtract(int a, int b) throws ArithmeticException {
        return 0; // Implement subtraction logic here
    }

    @Override
    public int multiply(int a, int b) throws ArithmeticException {
        return 0; // Implement multiplication logic here
    }

    @Override
    public int divide(int a, int b) throws ArithmeticException {
        return 0; // Implement division logic here
    }
}
