import java.io.IOException;

public class Calculatorapp {
    public static void main(String[] args) throws IOException {

        SimpleCalculator simplcalculatori = new SimpleCalculator();
        simplcalculatori.add(11,12);
    }
}
