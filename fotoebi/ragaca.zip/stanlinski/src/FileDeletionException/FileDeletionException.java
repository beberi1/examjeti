package FileDeletionException;

public class FileDeletionException extends Exception {
    public FileDeletionException(String message) {
        super(message);
    }
}
