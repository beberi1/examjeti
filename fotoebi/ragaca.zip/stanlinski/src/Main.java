// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.


//შექმენით Interface სახელწოდებით FileSystemImpl, რომელიც შეიცავს შემდეგ მეთოდებს:
//
//        void copyFile (string sourceFileName, string destinationFileName) throws FileCopyException
//        void deleteFile(String fileName) throws FileDeletionException
//
//        შექმენით კლასი სახელწოდებით FileProcessor და დააიმპლემენტირეთ ეს მეთოდები:
//
//        განახორციელეთ copyFile მეთოდი ფაილის დასაკოპირებლად sourceFileName-დან destinationFileName-მდე.
//        გამონაკლისების დამუშავება custom გამონაკლისის კლასის შექმნით სახელად FileCopyException.
//
//        განახორციელეთ deleteFile მეთოდი, რომ წაშალოთ ფაილი მოცემული ფაილის სახელით.
//        გამონაკლისების დამუშავება custom გამონაკლისის კლასის შექმნით სახელად FileDeletionException.
//
//        დაწერეთ სატესტო პროგრამა, რომელიც აჩვენებს FileProcessor კლასის გამოყენებას.
//        ნება მიეცით მომხმარებლებს დააკოპირონ და წაშალონ ფაილები და გაუმკლავდნენ გამონაკლისებს
//        მორგებული გამონაკლისების კლასების გამოყენებით. ჩაწერეთ ყველა ფაილის ოპერაცია
//        და გამონაკლისი java.util.logging ჩარჩოს გამოყენებით.


import FileCopyException.FileCopyException;
import FileDeletionException.FileDeletionException;

import java.io.*;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Main {
    public static void main(String[] args) throws IOException, FileCopyException, FileDeletionException {
        String pirveli = "input.txt";
        String meore = "output.txt";

        FileProcessor failis = new FileProcessor();



//        System.out.println("mitxari ra ginda rom gavaketo");
//        System.out.println("dawere 1 rom davakopiro: dawere 2 rom wavshalo");

        Logger logger = Logger.getLogger(Main.class.getName());
        FileHandler fileHandler = new FileHandler("mylog.log", true);
        SimpleFormatter formatter = new SimpleFormatter();
        fileHandler.setFormatter(formatter);
        logger.addHandler(fileHandler);


        while (true){

            System.out.println("mitxari ra ginda rom gavaketo");
            System.out.println("dawere 1 rom davakopiro: dawere 2 rom wavshalo");

            Scanner skaneri = new Scanner(System.in);
            int sheyvanili = skaneri.nextInt();

            if (sheyvanili == 3 || sheyvanili == 0){
                return;
            }

            System.out.println(sheyvanili);

            if (sheyvanili == 1){
                failis.copyFile(pirveli,meore);
//                System.out.println("dakopirda");
                logger.info("File copied from " + pirveli + " to " + meore);
            } else if (sheyvanili == 2){
                failis.deleteFile(meore);
                System.out.println("waishala");
                logger.info("File deleted: " + meore);
            } else {
                System.out.println("ragac shecdomaaa");
            }

        }







//        FileInputStream inp = new FileInputStream("input.txt");
//        FileOutputStream out = new FileOutputStream("output.txt");
//        int c;
//
//        while( (c = inp.read()) != -1){     //amas sheaq pirveli failidan meoreshi
//            out.write(c);
//        }
//
//        inp.close();
//        out.close();
//
//
//
//        File wasashleli = new File("output.txt");
//        if (wasashleli.delete()){
//            System.out.println("warmatebit waishala");         //failis washla
//        } else {
//            System.out.println("ragac moxda da ver waishala");
//
//        }


    }
}