import FileCopyException.FileCopyException;
import FileDeletionException.FileDeletionException;

import java.io.*;

public class FileProcessor implements FileSystemImpl {


    public static void main(String[] args) {
    }

    @Override
    public void copyFile(String sourceFileName, String destinationFileName) throws FileCopyException, IOException {
        FileInputStream in = new FileInputStream("input.txt");
        FileOutputStream out = new FileOutputStream("output.txt");
        int c;

        while ((c = in.read()) != -1) {
            out.write(c);
        }

        in.close();
        out.close();
    }

    @Override
    public void deleteFile(String fileName) throws FileDeletionException {
        File wasashleli = new File("output.txt");
        if (wasashleli.delete()){
            System.out.println("warmatebit waishala");
        } else {
            System.out.println("ragac moxda da ver waishala");
        }
    }
}
