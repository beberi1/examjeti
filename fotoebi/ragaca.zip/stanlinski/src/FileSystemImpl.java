import FileCopyException.FileCopyException;
import FileDeletionException.FileDeletionException;

import java.io.IOException;

public interface FileSystemImpl {
    void copyFile(String sourceFileName, String destinationFileName) throws FileCopyException, IOException;
    void deleteFile(String fileName) throws FileDeletionException;
}
