package FileCopyException;

public class FileCopyException extends Exception {
    public FileCopyException(String message) {
        super(message);
    }
}
