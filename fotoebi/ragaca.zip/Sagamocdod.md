

VLAN

en
conf t
vlan 10
name ragaca
exit

interface GigabitEthernet1/0                                                                          
 switchport mode access                                                                               
 switchport access vlan 10


switchport mode trunk
switchport trunk native vlan 10




vtp server:
conf t
vtp mode server
end


vtp domain ? 
vtp domain ccna
vtp password rameparoli
show vtp password


vtp mode client
vtp domain ccna
vtp password racaa

Trunk უნდა იყოს იმისთვის რო იმუშავოს



sub interfaces:
int gig0/0.10
encapsulation dot1Q 10
ip address 192.168.10.1 255.255.255.0

vlan 99 native - ორივე სვიჩზე და interface vlan 99 ზე შედი და აიპი გაუწერე
და არ დაგავიწყდეს defauult-gateway

SSH:
conf t
ip domain name cisco.com
username saxeli secret paroli
crypto key generate rsa
1024
line vty 0 15
login local
enable secret cisco123
transport input ? - და აირჩევ რომელიმეს ან არ აირჩევ და ოლზე იქნება







3 IPv6 Static and Default Routes

en
conf t
int gig0/2
ipv6 address 2001:Db8:acad:b::1/64
no shut
ex

ipv6 unicast routing
ipv6 route 2001:db8:acad:b::/64 serial 0/0/0


4 ipv4 and ipv6 default route

directly = interface
hop = ip

ip route 0.0.0.0 0.0.0.0 serial 0/0/0

ipv6 route ::/0 serial0/0/1







5 EIGRP

router eigrp 1
network 172.16.1.0 0.0
passive-interface g0/0

no auto-summary



ipv6 unicast-routing
ipv6 router eigrp 1
eigrp router-id 1.1.1.1










6 OSPF v2


router ospf 10
router-id 1.1.1.1
network 172.16.1.0 0.0.0.255 area 0
network 172.16.3.0 0.0.0.3 area 0
network 172.167.10.4 0.0.0.3 area 0
passive-interface gig0/0
Ctrl+z
copy running-config startup-config








7 OSPF v3

ipv6 unicast-routing
ipv6 router ospf 10
router-id 1.1.1.1


show ipv6 interface brief
რომელ ინტერფეისებსაც იყენებ იმათზე უნდა გაწერო

interface gigabit ethernet 0/0
ipv6 ospf 10  area 0

int se0/0/0
ipv6 ospf 10 area 0

int se 0/0/1
ipv6 ospf 10 area 0







8 NAT

access-list 1 permit 172.16.0.0 0.0.255.255

ip nat pool ANY_POOL_NAME 209.165.200.233 209.165.200.234 netmask 255.255.255.252

ip nat inside source list 1 pool ANY_POOL_NAME overload


**interface s0/1/0**
**ip nat outside**
**interface g0/0/0**
**ip nat inside**
**interface g0/0/1**
**ip nat inside**


show ip nat translations

ip nat inside source list 2 interface s0/1/1 overload


ip nat inside source static { local-ip global-ip} - უნდა იყოს დეფაულტ როუტი ინტერნეტთან
interface serial0/0/0
ip nat inside
exit
interface seriak0/0/1
ip nat outside

show ip nat translations

show ip nat statistics



Dynamic
ip nat pool { name start-ip end-ip }
access-list { access-list}  permit source source
ip nat inside source list access-list-number pool name
interface number
ip nat inside

interface number
ip nat outside







Access lists


access-list ACL-# {deny | permit | remark} source [source-wildcard]]log

access-list 1 permit 192.168.10.0 0.0.0.255
interface g0/0
ip access-group 1 out


access-list standart NO_ACCESS
deny host 192.168.11.10
permit any
exit
g0/0
ip access-group No_ACCESS





